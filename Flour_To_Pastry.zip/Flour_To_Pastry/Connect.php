<?php 
$host="localhost";
$user="root";
$pass="";
$db="flour_to_pastry";
$conn= mysqli_connect($host,$user,$pass,$db);
$dbconnect= mysqli_select_db($conn,$db);

if($dbconnect){
     
 }
 else{
    echo "no connection";
 }
?>