<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flour to pastry</title>
    <link rel="stylesheet" href="css/home.css">
</head>
<body>
    <section>
        <div class="circle">

        </div>
        <header>
            <a href="#" class="logo"><img src = "images/logo.png"></a>
            <div class="toggle" onclick="toggleMenu();"></div>
            <ul class="navigation">
                <li class="hov"><a href="Home.php">Home</a></li>
                <li class="hov"><a href="Menu.php">Menu</a></li>
                <li class="hov"><a href="Orders.php">Order</a></li>
                <li class="hov"><a href="Details.php">Cart</a></li>
                <li class="hov"><a href="About.php">About us</a></li>
                <li class="hov">
                    <?php 
                        session_start();
                        if(!empty($_SESSION['username'])){
                            // 
                            echo'<a href="#">';
                            echo $_SESSION['username'];
                            echo '</a>';
                        }else{
                            echo '<a href="Login.php"> Sign Up/Login </a>';
                        }
                    ?>
                </li>
            </ul>
        </header>
        <div class="content">
            <div class="textBox">
                <h2>Its not just a cake<br>Its<br> <span>Flour To Pastry</span> </h2>
                <p>We create an ideal combination of sweetness of cake and touch of homemade food. Want to grab a slice of blissful sweetmeat?
Order yours at a reasonable price from us.<br>
                <a href="About.html">Learn More</a>
            </div>
            <div class="imgBox">
                <img src="images/1.png" class="starbucks"alt="">
            </div>
        </div>
        <ul class="thumb">
            <li><img src ="images/thumb1.png" onclick="imgSlider('images/1.png'); changeCircleColor('#eb7495')"></li>
            <li><img src ="images/thumb2.png" onclick="imgSlider('images/2.png'); changeCircleColor('#296d9e')"></li>
            <li><img src ="images/thumb3.png" onclick="imgSlider('images/3.png'); changeCircleColor('#5c1f1f')"></li>
        </ul>
        <ul class="sci">
            <li><a href="https://www.facebook.com/flourtopastry"><img src="images/facebook.png"></a></li> 
            <li><a href="#"><img src="images/twitter.png"></a></li>
            <li><a href="#"><img src="images/instagram.png"></a></li>
        </ul>
    </section>
    <script type="text/javascript">
        function imgSlider(anything){
            document.querySelector('.starbucks').src = anything;
        }

        function changeCircleColor(color){
            const circle = document.querySelector('.circle');
            circle.style.background = color;
        }function toggleMenu(){
            var menuToggle = document.querySelector('.toggle');
            var navigation = document.querySelector('.navigation')
            menuToggle.classList.toggle('active')
            navigation.classList.toggle('active')
        }


    </script>
</body>


</html>