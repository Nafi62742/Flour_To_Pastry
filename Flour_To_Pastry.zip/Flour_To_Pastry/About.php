<!DOCTYPE html>
<html>
    
    <title>Flour To Pastry</title>

    <section>
      <head>
          <!-- Required meta tags -->
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
  
          <!-- Bootstrap CSS -->
          <link href="css/bootstrap.min.css" rel="stylesheet" />
          <link rel="stylesheet" href="css/about.css" />
      </head>
      <body>
        <header>
              <a href="#" class="logo"><img src = "images/logo.png"></a>
              <div class="toggle" onclick="toggleMenu();"></div>
              <ul class="navigation">
              <li class="hov"><a href="Home.php">Home</a></li>
                <li class="hov"><a href="Menu.php">Menu</a></li>
                <li class="hov"><a href="Orders.php">Order</a></li>
                <li class="hov"><a href="Details.php">Cart</a></li>
                <li class="hov"><a href="About.php">About us</a></li>
                <li class="hov">
                    <?php 
                        session_start();
                        if(!empty($_SESSION['username'])){
                            // 
                            echo'<a href="#">';
                            echo $_SESSION['username'];
                            echo '</a>';
                        }else{
                            echo '<a href="Login.php"> Sign Up/Login </a>';
                        }
                    ?>
                </li>
              
              </ul>
          </header>
      
         
  
      
          <div class="container-fluid px-4">
              <div class="row justify-content-center mb-5 pb-2">
                  <div class="col-md-7 text-center heading-section ftco-animate">
                      <div class="heading">
                      <p>About Us</p>
                    </div>
                      
                        <div class="des">
                        <p>Flour To Pastry creates an ideal combination of sweetness of cake and touch of homemade food. Want to grab a slice of blissful sweetmeat?
                            Order yours at a reasonable price from us.
                            "Your hygiene is our first concern."
                        </p>
                    </div>
                      
                  </div>
              </div>
  
              <div class="row">
                      <!-- <div class="menus d-flex ftco-animate">
                          <div class="menu-img img" style="background-image: url(images/twitter.png);"></div>
                          <div class="text">
                              <div class="d-flex">
                                  <div class="one-half">
                                      <h3>Swapneel Biswas</h3>
                                      <p>180204026</p>
                                  </div>                            
                              </div>
                          </div>
                      </div> -->
                      <?php
                        include_once  'Connect.php';
                        $query = "SELECT * from admin ";
                        $query_run= mysqli_query($conn,$query);
                        $check_team= mysqli_num_rows($query_run)>0;

                        if($check_team)
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                            ?>
                            <div class="menus d-flex ftco-animate">
                                <div class="menu-img img" style="background-image: url(images/twitter.png);"></div>
                                <div class="text">
                                    <div class="d-flex">
                                        <div class="one-half">
                                            <h3><?php echo $row['AdminName']; ?> </h3>
                                            <p><?php echo $row['PhoneNo']; ?></p>
                                            <p><?php echo $row['AboutAdmin']; ?></p>                
                                        </div>                              
                                    </div>                             
                                </div>
                            </div> 
                      <?php
                            }
                        }
                        else{
                            ?>
                        
                        <?php    
                        }
                        ?>
              </div>
          </div>   
  </section>

  <script src="js/bootstrap.bundle.min.js"></script>


  <script type="text/javascript">

    function toggleMenu(){
        var menuToggle = document.querySelector('.toggle');
        var navigation = document.querySelector('.navigation')
        menuToggle.classList.toggle('active')
        navigation.classList.toggle('active')
    }


</script>
</body>
</html>