<!DOCTYPE html>
<html>

<title>Flour To Pastry</title>
<section>
    <div class="sectionAll">

        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- Bootstrap CSS -->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
                integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU"
                crossorigin="anonymous">
            <link href="css/bootstrap.min.css" rel="stylesheet" />
            <link rel="stylesheet" href="css/menu.css" />
        </head>

        <body>
            <header>
                <a href="#" class="logo"><img src="images/logo.png"></a>
                <div class="toggle" onclick="toggleMenu();"></div>
                <ul class="navigation">
                <li class="hov"><a href="Home.php">Home</a></li>
                <li class="hov"><a href="Menu.php">Menu</a></li>
                <li class="hov"><a href="Orders.php">Order</a></li>
                <li class="hov"><a href="Details.php">Cart</a></li>
                <li class="hov"><a href="About.php">About us</a></li>
                <li class="hov">
                    <?php 
                        session_start();
                        if(!empty($_SESSION['username'])){
                            // 
                            echo'<a href="#">';
                            echo $_SESSION['username'];
                            echo '</a>';
                        }else{
                            echo '<a href="Login.php"> Sign Up/Login </a>';
                        }
                    ?>
                </li>
                </ul>
            </header>




            <div class="container-fluid px-4">
                <div class="row justify-content-center mb-5 pb-2">
                    <div class="col-md-7 text-center heading-section ftco-animate">
                        <span class="subheading">Specialities</span>
                        <h2 class="mb-4">Our Menu</h2>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-lg-4 menu-wrap">
                        <div class="heading-menu text-center ftco-animate">
                            <h3>Cakes</h3>
                        </div>
                        <?php
                        include_once  'Connect.php';
                        $query = "SELECT * from cakeinfo ";
                        $query_run= mysqli_query($conn,$query);
                        $check_team= mysqli_num_rows($query_run)>0;

                        if($check_team)
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                            ?>
                                <div class="menus d-flex ftco-animate">
                                    <div class="menu-img img" style="background-image: url(images/twitter.png);"></div>
                                    <div class="text">
                                        <div class="d-flex">
                                            <div class="one-half">
                                                <h3><?php echo $row['CakeName']; ?></h3>

                                            </div>
                                            <div class="one-forth">
                                                <span class="price">$<?php echo $row['CakePrice'];?></span>
                                            </div>
                                        </div>
                                        <p>
                                            <span><?php echo $row['CakeDetails']; ?></span>
                                        </p>
                                    </div>
                                </div>
                      <?php
                            }
                        }
                        else{
                            ?>
                                 <div class="menus d-flex ftco-animate">
                                    <div class="menu-img img" style="background-image: url(incognito/1.png);"></div>
                                    <div class="text">
                                        <div class="d-flex">
                                            <div class="one-half">
                                                <h3>No Cake Added</h3>

                                            </div>
                                            <div class="one-forth">
                                                <span class="price">No price here</span>
                                            </div>
                                        </div>
                                        <p>
                                            <span>NO data here</span>
                                        </p>
                                    </div>
                                </div>
                        <?php    
                        }
                        ?>
                    </div>
                    <div class="col-md-6 col-lg-4 menu-wrap">
                        <div class="heading-menu text-center ftco-animate">
                            <h3>Wedding Cake</h3>
                        </div>
                        <?php
                        include_once  'Connect.php';
                        $query = "SELECT * from type2cake ";
                        $query_run= mysqli_query($conn,$query);
                        $check_team= mysqli_num_rows($query_run)>0;

                        if($check_team)
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                            ?>
                                <div class="menus d-flex ftco-animate">
                                    <div class="menu-img img" style="background-image: url(images/twitter.png);"></div>
                                    <div class="text">
                                        <div class="d-flex">
                                            <div class="one-half">
                                                <h3><?php echo $row['CakeName']; ?></h3>

                                            </div>
                                            <div class="one-forth">
                                                <span class="price">$<?php echo $row['CakePrice'];?></span>
                                            </div>
                                        </div>
                                        <p>
                                            <span><?php echo $row['CakeDetails']; ?></span>
                                        </p>
                                    </div>
                                </div>
                      <?php
                            }
                        }
                        else{
                            ?>
                                 <div class="menus d-flex ftco-animate">
                                    <div class="menu-img img" style="background-image: url(incognito/1.png);"></div>
                                    <div class="text">
                                        <div class="d-flex">
                                            <div class="one-half">
                                                <h3>No Cake Added</h3>

                                            </div>
                                            <div class="one-forth">
                                                <span class="price">No price here</span>
                                            </div>
                                        </div>
                                        <p>
                                            <span>NO data here</span>
                                        </p>
                                    </div>
                                </div>
                        <?php    
                        }
                        ?>                        
                    </div>
                    <div class="col-md-6 col-lg-4 menu-wrap">
                        <div class="heading-menu text-center ftco-animate">
                            <h3>Pastries</h3>
                        </div>
                        <?php
                        include_once  'Connect.php';
                        $query = "SELECT * from type3cake ";
                        $query_run= mysqli_query($conn,$query);
                        $check_team= mysqli_num_rows($query_run)>0;

                        if($check_team)
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                            ?>
                                <div class="menus d-flex ftco-animate">
                                    <div class="menu-img img" style="background-image: url(images/twitter.png);"></div>
                                    <div class="text">
                                        <div class="d-flex">
                                            <div class="one-half">
                                                <h3><?php echo $row['CakeName']; ?></h3>

                                            </div>
                                            <div class="one-forth">
                                                <span class="price">$<?php echo $row['CakePrice'];?></span>
                                            </div>
                                        </div>
                                        <p>
                                            <span><?php echo $row['CakeDetails']; ?></span>
                                        </p>
                                    </div>
                                </div>
                      <?php
                            }
                        }
                        else{
                            ?>
                                 <div class="menus d-flex ftco-animate">
                                    <div class="menu-img img" style="background-image: url(incognito/1.png);"></div>
                                    <div class="text">
                                        <div class="d-flex">
                                            <div class="one-half">
                                                <h3>No Cake Added</h3>

                                            </div>
                                            <div class="one-forth">
                                                <span class="price">No price here</span>
                                            </div>
                                        </div>
                                        <p>
                                            <span>NO data here</span>
                                        </p>
                                    </div>
                                </div>
                        <?php    
                        }
                        ?>                        
                    </div>
                </div>
            </div>
    </div>
</section>

<section>


    <div class="conatainer">
        <div class="row">
            <div class="col-md-12">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0"
                            class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                            aria-label="Slide 2"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="single-box">
                                        <div class="img-area"><img src="images/thumb1.png" alt=""></div>
                                        <div class="img-text">
                                            <h2>Person one</h2>
                                            <p>napi bolod khali ghumay ar rage. Pocha boy. meye baj napi</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-box">
                                        <div class="img-area"><img src="images/thumb1.png" alt=""></div>
                                        <div class="img-text">
                                            <h2>Person toe</h2>
                                            <p>napi bolod khali ghumay ar rage. Pocha boy. meye baj napi</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-box">
                                        <div class="img-area"><img src="images/thumb2.png" alt=""></div>
                                        <div class="img-text">
                                            <h2>Person thiri</h2>
                                            <p>napi bolod khali ghumay ar rage. Pocha boy. meye baj napi</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="carousel-item">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="single-box">
                                        <div class="img-area"><img src="images/thumb3.png" alt=""></div>
                                        <div class="img-text">
                                            <h2>Person one</h2>
                                            <p>napi bolod khali ghumay ar rage. Pocha boy. meye baj napi</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-box">
                                        <div class="img-area"><img src="images/thumb2.png" alt=""></div>
                                        <div class="img-text">
                                            <h2>Person toe</h2>
                                            <p>napi bolod khali ghumay ar rage. Pocha boy. meye baj napi</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-box">
                                        <div class="img-area"><img src="images/thumb3.png" alt=""></div>
                                        <div class="img-text">
                                            <h2>Person thiri</h2>
                                            <p>napi bolod khali ghumay ar rage. Pocha boy. meye baj napi</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="circle">

    </div>

</section>



<script type="text/javascript">

    function toggleMenu() {
        var menuToggle = document.querySelector('.toggle');
        var navigation = document.querySelector('.navigation')
        menuToggle.classList.toggle('active')
        navigation.classList.toggle('active')
    }


</script>






<script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>