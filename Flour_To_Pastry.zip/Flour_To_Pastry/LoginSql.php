<?php
$login =false;
session_start();
include_once 'Connect.php';

    $loginName=$_POST['UserName'];
    $loginPassword= $_POST['passwordLogin'];
    $sql ="SELECT * FROM userdata WHERE Name='$loginName' and password	= '$loginPassword';";
    $resultLogin = mysqli_query($conn, $sql);
   
    $res_no= mysqli_num_rows($resultLogin);

    if($res_no==1)
    {   
        $sql ="SELECT * FROM loginstatus WHERE Name='$loginName' and password	= '$loginPassword' ;";
        $resultStatus = mysqli_query($conn, $sql);
        $status_row= mysqli_num_rows($resultStatus);
        if($res_no==1)
        { 
            $sql ="UPDATE loginstatus set status = 1 WHERE Name='$loginName' and password	= '$loginPassword' status=1;";
            $resultStatus = mysqli_query($conn, $sql);
        }
        else{

            
        }
            // update login_info set state =? "
            // + " where id = \'"+id+"\' and ip_address=\'"+myIP.getHostAddress()+"\'
            // sql = "INSERT INTO login_info(id,ip_address,state) "
            // + "VALUES('"+id+"','"+myIP.getHostAddress()+"',"+1+")";

        // echo "Login successfully..."; 
        $_SESSION['username']= $loginName;
        $login=true;
        header('location:Home.php');
    }
    else{
        echo "Login Error..."; 
    }
?>