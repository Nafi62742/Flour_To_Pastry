<!DOCTYPE html>
<html>
    
    <title>Flour To Pastry</title>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
   
         <header>
            <a href="#" class="logo"><img src = "images/logo.png"></a>
            <div class="toggle" onclick="toggleMenu();"></div>
            <ul class="navigation">
            <li class="hov"><a href="Home.php">Home</a></li>
                <li class="hov"><a href="Menu.php">Menu</a></li>
                <li class="hov"><a href="Orders.php">Order</a></li>
                <li class="hov"><a href="Details.php">Cart</a></li>
                <li class="hov"><a href="About.php">About us</a></li>
                <li class="hov">
                    <?php 
                        session_start();
                        if(!empty($_SESSION['username'])){
                            // 
                            echo'<a href="#">';
                            echo $_SESSION['username'];
                            echo '</a>';
                        }else{
                            echo '<a href="Login.php"> Sign Up/Login </a>';
                        }
                    ?>
                </li>
            </ul>
        </header>



          <div class="container">
            <div class="row d-flex">
                <div class="col-md-7 ftco-animate makereservation p-4 px-md-5 pb-md-5">
                    <div class="heading-section ftco-animate mb-5 text-center">
                        <span class="subheading">Order</span>
                        <h2 class="mb-4">Your Cake</h2>
                    </div>
                    <form action="#">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" class="form-control" placeholder="Enter Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="email" class="form-control" placeholder="someone@gmail.com">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Address</label>
                                    <input type="text" class="form-control" placeholder="XYZ">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" class="form-control" placeholder="9874563215">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Date</label>
                                    <input type="text" class="form-control" id="book_date" placeholder="Date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Time</label>
                                    <input type="text" class="form-control" id="book_time" placeholder="Time">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Cake Flavour</label>
                                    <div class="select-wrap one-third">
                                        <div class="icon"><span class="ios-ios-arrow-down"></span></div>
                                        <select name="" id="" class="form-control">
                                            <option value="">Vanilla</option>
                                            <option value="">Chocolate</option>
                                            <option value="">Blackforest</option>
                                            <option value="">Blueberry</option>
                                            <option value="">Mango</option>
                                            <option value="">Strawberry</option>
                                            <option value="">Butterscotch</option>
                                            <option value="">Mudcake</option>
                                            <option value="">Redvalvet</option>

                                            <option value="">New York Style Baked Cheesecake</option>
                                            <option value="">Japanese Cotton Cheesecake</option>
                                        </select>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Kg</label>
                                    <div class="select-wrap one-third">
                                        <div class="icon"><span class="ios-ios-arrow-down"></span></div>
                                        <select name="" id="" class="form-control">
                                            <option value="">0.5</option>
                                            <option value="">1</option>
                                            <option value="">1.5</option>
                                            <option value="">2.5</option>
                                            <option value="">5</option>
                                            <option value="">10</option>
                                            <option value="">Custom</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 mt-3">
                                <div class="form-group text-center">
                                    <input type="submit" value="Order Your Cake" class="btn btn-primary py-3 px-5">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


          <footer>
            <p>&copy; Copyright 2021. All Rights Reserved</p>
          </footer>
        
          <script src="js/bootstrap.bundle.min.js"></script>

          <script type="text/javascript">

            function toggleMenu(){
                var menuToggle = document.querySelector('.toggle');
                var navigation = document.querySelector('.navigation')
                menuToggle.classList.toggle('active')
                navigation.classList.toggle('active')
            }
        
        
        </script>
            </body>
        </html>