<?php
include_once 'Connect.php';

$Name=$_POST['RegName'];

$email=$_POST['email'];
$pNumber= $_POST['pNumber'];
$password= $_POST['password'];

$checkerSql = " SELECT * FROM userdata WHERE Name='$loginName' and password	= '$loginPassword' AND email='$emal';";
$CheckLogin = mysqli_query($conn, $checkerSql);
   
$Rows= mysqli_num_rows($CheckLogin);

if($Rows==1)
{   
     echo "Account exists"; 

}else{

    $sql ="INSERT into userdata(Name,lastName,email,pNumber,password)
    values('$RegName' , '$email' , '$pNumber', '$password')";
    $result= mysqli_query($conn, $sql);
    session_start();
    header("location:Login.php");

} 

?>