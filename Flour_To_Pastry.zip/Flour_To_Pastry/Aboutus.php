<?php
session_start();
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
  $loggedin= true;
}
else{
  $loggedin = false;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Pamphlet and flicks</title>
       <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel= "stylesheet" href = "style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"/>
    </head>
    <body>
  <div class="container py-5">
    <div class="row mt-4">
    <?php
     include_once  'Connect.php';
     $query = "SELECT * from admin ";
     $query_run= mysqli_query($conn,$query);
     $check_team= mysqli_num_rows($query_run)>0;

    if($check_team)
    {
        while($row = mysqli_fetch_assoc($query_run))
        {
        ?>
        <div class="col-md-6 mt-3">
            <div class="card" >
             <!-- <img src="<?php echo $row["image"]; ?>"; height="350" wudth="100"> -->
                <div class="card-body">
                    <h2 class="card-title"> <?php echo $row['AdminName']; ?> </h2>
                    <h3 class="card-title"> <?php echo $row['PhoneNo']; ?> </h3>
                    <h4 class="card-title"> <?php echo $row['AboutAdmin']; ?> </h4>
                </div>
            </div>
          </div>
        <?php
        }
    }
    else{
        echo "No admin here. Go back.";
    }
    ?>
    </div>
</div>
  <footer>
        <p class= "p-5 bg-dark text-white text-center"> kisujanina@gmail.com</p>
  </footer>
</body>
</html>